
package collage_management;

import com.toedter.calendar.JDateChooser;
import java.sql.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
public class Library extends JFrame implements ActionListener,ItemListener{
    JLabel l1,l2,l3,l4,l5,l6;
    JTextField t1,t2,t3,t4,t5;
    JButton b1,b2;
    Choice c1,c2;
    JPanel contentPane;
     JDateChooser ch,ch2;
    public Library(){
        contentPane=new JPanel();
    contentPane.setBorder(new EmptyBorder(5,5,5,5));
    setContentPane(contentPane);
    contentPane.setLayout(null);
    setSize(500,600);
    
    
    setLayout(null);
    Dimension dn =Toolkit.getDefaultToolkit().getScreenSize();
                int xx1=dn.width/2-this.getWidth()/2;
                int yy1=dn.height/2-this.getHeight()/2;
                setLocation(xx1,yy1);
    
    l6=new JLabel("Library Management");
     l6.setFont(new Font("serif",Font.ITALIC| Font.BOLD,30));
     l6.setBounds(100,20,300,100);
     add(l6);
     
    
        
    
     
      l2=new JLabel("RollNo");
     l2.setBounds(70,130,100,30);
     l2.setFont(new Font("serif",Font.BOLD,20));
     add(l2);
     
     
     
      c2=new Choice();
    c2.setForeground(new Color(23,45,75));
    c2.setFont(new Font("Trebuchet MS",Font.BOLD,14));
   c2.addItemListener(this);
    try{
   conn c=new conn();
    ResultSet rs=c.s.executeQuery("select * from AddStudent");
    while(rs.next()){
    c2.add(rs.getString("Rollno"));
    }
    }
   
    catch(Exception e){}
     
     
     c2.setBounds(200,130,160,50);
     add(c2);
     
     
      l1=new JLabel("Name");
     l1.setBounds(70,200,100,30);
     l1.setFont(new Font("serif",Font.BOLD,20));
     add(l1);
     
     t2=new JTextField();
    t2.setForeground(new Color(23,45,75));
     t2.setBounds(200,200,160,30);
     t2.setEditable(false);
    t2.setFont(new Font("Trebuchet MS",Font.BOLD,14));
     add(t2);
   
      
      
      l3=new JLabel("Book Name");
     l3.setBounds(70,270,200,30);
     l3.setFont(new Font("serif",Font.BOLD,20));
     add(l3);
     
     t3=new JTextField();
     t3.setBounds(200,270,160,30);
     t3.setFont(new Font("serif",Font.BOLD,20));
     add(t3);
     
      l4=new JLabel("Issue Date");
     l4.setBounds(70,340,200,30);
     l4.setFont(new Font("serif",Font.BOLD,20));
     add(l4);
     
      ch = new JDateChooser();
     ch.setDateFormatString("dd/MM/yyyy");
     
    ch.setBounds(200,340,160,30);
     ch.setFont(new Font("serif",Font.BOLD,15));
     add(ch);
     
      l5=new JLabel("Submit Date");
     l5.setBounds(70,410,200,30);
     l5.setFont(new Font("serif",Font.BOLD,20));
     add(l5);
     
     ch2 = new JDateChooser();
     ch2.setDateFormatString("dd/MM/yyyy");
     ch2.setBounds(200,410,160,30);
     ch2.setFont(new Font("serif",Font.BOLD,15));
     add(ch2);
     
    b1=new JButton("Save");
      b1.setBackground(Color.orange);
      b1.setForeground(Color.white);
      
      b1.setBounds(100,470,100,30);
      add(b1);   
      
     b2=new JButton("Cancle");
      b2.setBackground(Color.black);
      b2.setForeground(Color.white);
      b2.setBounds(230,470,100,30);
      add(b2);  
      
      b1.addActionListener(this);
      b2.addActionListener(this);
      
        JPanel panel=new JPanel();
    panel.setBorder(new TitledBorder(new LineBorder(new Color(102,205,170),2,true),"LIBRARY_BOOK",TitledBorder.LEADING,TitledBorder.TOP,null,new Color(30,144,255)));
    panel.setBackground(new Color(34,56,255));
    panel.setBounds(10,30,460,500);
    
    contentPane.setBackground(Color.white);
    panel.setBackground(Color.white);
    contentPane.add(panel);
    }
    public void itemStateChanged(ItemEvent ae){
     if(ae.getSource()==c2){
        try{
    conn c=new conn();
    ResultSet rs=c.s.executeQuery("select * from AddStudent where rollno='"+c2.getSelectedItem()+"'");
    while(rs.next()){
    t2.setText(rs.getString("name"));
   
    
    
    
     
    }
    }
    catch(Exception e){}
        }
    }
    public void actionPerformed(ActionEvent ae){
        
    if(ae.getSource()==b1){
        String empt="";
        if(t2.getText().equals(empt) || t3.getText().equals(empt) || ch.getDate().equals(empt) || ch2.getDate().equals(empt))
        {
            JOptionPane.showMessageDialog(null,"Plase enter empty field in value");   
        }
        else
        {
      
        
        try{
             String st2=(String)c2.getSelectedItem();
             String ddd1=((JTextField)ch.getDateEditor().getUiComponent()).getText();
             String ddd2=((JTextField)ch2.getDateEditor().getUiComponent()).getText();
            String st="insert into library values('"+t2.getText()+"','"+st2+"','"+t3.getText()+"','"+ddd1+"','"+ddd2+"')";
           

            
           conn con=new conn();
       
          int i= con.s.executeUpdate(st);
           
           JOptionPane.showMessageDialog(null,"Successfully Insert ");
           
           
           t2.setText("");
           t3.setText("");
           t4.setText("");
           t5.setText("");
           
           t1.requestFocus();

        }
           
        
        catch(Exception e){
            System.out.println(e);
        }
        }
        
    }
    else{
    System.exit(0);
    }
    
    }
    public static void main(String[] args) {
       new Library().setVisible(true);
    }
    
}
