package collage_management;
import com.toedter.calendar.JDateChooser;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.Date;
import java.util.regex.*;

public class AddTeacher extends JFrame implements ActionListener {

        JLabel id,id1,id2,id3,id4,id5,id6,id7,id8,id9,id10,id11,id12,id13,id14,id15,id16,id17,lb,lb1,lb2;
        JLabel v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11;
        JTextField t,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13;
        JButton b,b1;
        JComboBox c1,c2;
        JDateChooser ch;
        
         public AddTeacher(){
            
            setBackground(Color.white);
            setLayout(null);
            
            id=new JLabel();
            id.setBounds(0,0,900,700);
            id.setLayout(null);
//            setUndecorated(true);
//            getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
            
            id1=new JLabel("New Teacher Details");
            id1.setBounds(320,30,500,50);
            id1.setFont(new Font("serif",Font.ITALIC,25));
            id1.setForeground(Color.black);
            id.add(id1);
           add(id);
            
            id2=new JLabel("Name");
            id2.setBounds(50,150,100,30);
            id2.setFont(new Font("serif",Font.BOLD,20));
             id.add(id2);
          
             v1= new JLabel("");
             v1.setBounds(200,175,100,30);
             v1.setForeground(Color.red);
            v1.setFont(new Font("serif",Font.BOLD,12));
             id.add(v1);
             
            t1=new JTextField();
            t1.setBounds(200,150,150,30);
            String vv1="^[a-zA-Z]{0,10}$";
            t1.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv1);
                     Matcher mt= pt.matcher(t1.getText());
                     
                     if(mt.matches())
                     {
                      
                       v1.setText("true");
                       v1.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v1.setText("No Match Validation");
                       
                       v1.setForeground(Color.red);
                     }
                   }
                   
            });
            id.add(t1);
            
            
            id3=new JLabel("Father Name");
            id3.setBounds(400,150,200,30);
            id3.setFont(new Font("serif",Font.BOLD,20));
             id.add(id3);
             
             v2= new JLabel("");
             v2.setBounds(600,175,100,30);
             v2.setForeground(Color.red);
            v2.setFont(new Font("serif",Font.BOLD,12));
             id.add(v2);
             
            t2=new JTextField();
            t2.setBounds(600,150,150,30);
            String vv2="^[a-zA-Z]{0,11}$";
            t2.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv2);
                     Matcher mt= pt.matcher(t2.getText());
                     
                     if(mt.matches())
                     {
                      
                       v2.setText("true");
                       v2.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v2.setText("No Match Validation");
                       
                       v2.setForeground(Color.red);
                     }
                   }
                   
            });
            id.add(t2);
            
            id4=new JLabel("Age");
            id4.setBounds(50,200,150,30);
            id4.setFont(new Font("serif",Font.BOLD,20));
             id.add(id4);
             
             v3= new JLabel("");
             v3.setBounds(200,225,100,30);
             v3.setForeground(Color.red);
            v3.setFont(new Font("serif",Font.BOLD,12));
             id.add(v3);
             
            t3=new JTextField();
            t3.setBounds(200,200,150,30);
            String vv3="^[0-9]{1,3}$";
            t3.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv3);
                     Matcher mt= pt.matcher(t3.getText());
                     
                     if(mt.matches())
                     {
                      
                       v3.setText("true");
                       v3.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v3.setText("No Match Validation");
                       
                       v3.setForeground(Color.red);
                     }
                   }
                   
            });
            id.add(t3);
            
            id5=new JLabel("DOB(dd/mm/yy)");
            id5.setBounds(400,200,200,30);
            id5.setFont(new Font("serif",Font.BOLD,20));
             id.add(id5);
             
              v4= new JLabel("");
             v4.setBounds(600,225,100,30);
             v4.setForeground(Color.red);
            v4.setFont(new Font("serif",Font.BOLD,12));
             id.add(v4);
             
             
           
             
             ch = new JDateChooser();
             ch.setBounds(600,200,150,30);
             ch.setDateFormatString("dd/MM/yyyy");
             
            id.add(ch);
            
     
                    
            id6=new JLabel("Address");
            id6.setBounds(50,250,100,30);
            id6.setFont(new Font("serif",Font.BOLD,20));
             id.add(id6);
             
             
              v5= new JLabel("");
             v5.setBounds(200,275,100,30);
             v5.setForeground(Color.red);
            v5.setFont(new Font("serif",Font.BOLD,12));
             id.add(v5);
             
            t5=new JTextField();
            t5.setBounds(200,250,150,30);
            String vv5="^[a-zA-Z]{0,50}$";
            
            t5.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv5);
                     Matcher mt= pt.matcher(t5.getText());
                     
                     if(mt.matches())
                     {
                      
                       v5.setText("true");
                       v5.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v5.setText("No Match Validation");
                       
                       v5.setForeground(Color.red);
                     }
                   }
                   
            });
            id.add(t5);
            
            id7=new JLabel("Mobileno");
            id7.setBounds(400,250,200,30);
            id7.setFont(new Font("serif",Font.BOLD,20));
             id.add(id7);
             
              v6= new JLabel("");
             v6.setBounds(600,275,100,30);
             v6.setForeground(Color.red);
            v6.setFont(new Font("serif",Font.BOLD,12));
             id.add(v6);
             
             
            t6=new JTextField();
            t6.setBounds(600,250,150,30);
            String vv6="^[0-9]{10,10}$";
            t6.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv6);
                     Matcher mt= pt.matcher(t6.getText());
                     
                     if(mt.matches())
                     {
                      
                       v6.setText("true");
                       v6.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v6.setText("No Match Validation");
                       
                       v6.setForeground(Color.red);
                     }
                   }
                   
            });
            id.add(t6);
            
            id8=new JLabel("Email Id");
            id8.setBounds(50,300,100,30);
            id8.setFont(new Font("serif",Font.BOLD,20));
             id.add(id8);
             
              v7= new JLabel("");
             v7.setBounds(200,325,100,30);
             v7.setForeground(Color.red);
            v7.setFont(new Font("serif",Font.BOLD,12));
             id.add(v7);
             
            t7=new JTextField();
            t7.setBounds(200,300,150,30);
            String vv7="^(.+)@(.+).(.+)$";
            t7.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv7);
                     Matcher mt= pt.matcher(t7.getText());
                     
                     if(mt.matches())
                     {
                      
                       v7.setText("true");
                       v7.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v7.setText("No Match Validation");
                       
                       v7.setForeground(Color.red);
                     }
                   }
                   
            });
            id.add(t7);
            
            id9=new JLabel("Class X(%)");
            id9.setBounds(400,300,130,30);
            id9.setFont(new Font("serif",Font.BOLD,20));
             id.add(id9);
             
              v8= new JLabel("");
             v8.setBounds(600,325,100,30);
             v8.setForeground(Color.red);
            v8.setFont(new Font("serif",Font.BOLD,12));
             id.add(v8);
             
            t8=new JTextField();
            t8.setBounds(600,300,150,30);
            String vv8="^[0-9]{0,2}[.][0-9]{0,2}$";
            t8.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv8);
                     Matcher mt= pt.matcher(t8.getText());
                     
                     if(mt.matches())
                     {
                      
                       v8.setText("true");
                       v8.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v8.setText("No Match Validation");
                       
                       v8.setForeground(Color.red);
                     }
                   }
                   
            });
            id.add(t8);
            
            id10=new JLabel("Class Xll(%)");
            id10.setBounds(50,350,150,30);
            id10.setFont(new Font("serif",Font.BOLD,20));
             id.add(id10);
             
              v9= new JLabel("");
             v9.setBounds(200,375,100,30);
             v9.setForeground(Color.red);
            v9.setFont(new Font("serif",Font.BOLD,12));
             id.add(v9);
             
            t9=new JTextField();
            t9.setBounds(200,350,150,30);
            String vv9="^[0-9]{0,2}[.][0-9]{0,2}$";
            t9.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv9);
                     Matcher mt= pt.matcher(t9.getText());
                     
                     if(mt.matches())
                     {
                      
                       v9.setText("true");
                       v9.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v9.setText("No Match Validation");
                       
                       v9.setForeground(Color.red);
                     }
                   }
                   
            });
            id.add(t9);
            
            id11=new JLabel("Aadhar NO");
            id11.setBounds(400,350,100,30);
            id11.setFont(new Font("serif",Font.BOLD,20));
             id.add(id11);
             
              v10= new JLabel("");
             v10.setBounds(600,375,100,30);
             v10.setForeground(Color.red);
            v10.setFont(new Font("serif",Font.BOLD,12));
             id.add(v10);
             
            t10=new JTextField();
            t10.setBounds(600,350,150,30);
            String vv10="^[0-9]{12,12}$";
            t10.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv10);
                     Matcher mt= pt.matcher(t10.getText());
                     
                     if(mt.matches())
                     {
                      
                       v10.setText("true");
                       v10.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v10.setText("No Match Validation");
                       
                       v10.setForeground(Color.red);
                     }
                   }
                   
            });
            id.add(t10);
            
            id12=new JLabel("Employee No");
            id12.setBounds(50,400,150,30);
            id12.setFont(new Font("serif",Font.BOLD,20));
             id.add(id12);
             
              v11= new JLabel("");
             v11.setBounds(200,425,100,30);
             v11.setForeground(Color.red);
            v11.setFont(new Font("serif",Font.BOLD,12));
             id.add(v11);
             
            t11=new JTextField();
            t11.setBounds(200,400,150,30);
            String vv11="^[0-9]{0,4}$";
            t11.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv11);
                     Matcher mt= pt.matcher(t11.getText());
                     
                     if(mt.matches())
                     {
                      
                       v11.setText("true");
                       v11.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v11.setText("No Match Validation");
                       
                       v11.setForeground(Color.red);
                     }
                   }
                   
            });
            id.add(t11);
            
            lb=new JLabel("Cource");
            lb.setBounds(400,400,150,30);
            lb.setFont(new Font("serif",Font.BOLD,20));
             id.add(lb);
             
            String cource[] = {"Bca","Bsc-It","Bsc"};
            c1=new JComboBox(cource);
            c1.setBackground(Color.white);
            c1.setBounds(600,400,150,30);
            id.add(c1);
            
            lb1=new JLabel("Brance");
             lb1.setBounds(50,450,150,30);
            lb1.setFont(new Font("serif",Font.BOLD,20));
             id.add(lb1);
             
             String branch[]={"Computer","science"};
             c2=new JComboBox(branch);
             c2.setBackground(Color.white);
            c2.setBounds(200,450,150,30);
             id.add(c2);
             
             b=new JButton("Submit");
             b.setBackground(Color.BLACK);
             b.setForeground(Color.white);
             b.setBounds(250,550,150,40);
             id.add(b);
             
             
             
             b1=new JButton("Cancle");
             b1.setBackground(Color.BLACK);
             b1.setForeground(Color.white);
             b1.setBounds(450,550,150,40);
             id.add(b1);
             
             b.addActionListener(this);
             b1.addActionListener(this);
             ImageIcon i2=new ImageIcon(getClass().getResource("/collage_management/icon/fifth.jpg"));
        Image i1=i2.getImage().getScaledInstance(800, 700,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i1);
 
     JLabel m1=new JLabel("",i3,JLabel.LEFT);
     m1.setBounds(0,0,800,700);
     add(m1);
             
             setVisible(true);
             setSize(800,700);
             Dimension dn =Toolkit.getDefaultToolkit().getScreenSize();
                int xx1=dn.width/2-this.getWidth()/2;
                int yy1=dn.height/2-this.getHeight()/2;
                setLocation(xx1,yy1);
             
        
            
        }
        
        public void actionPerformed(ActionEvent ae){
            String blnk=null;
            String a=t1.getText();
            String bb=t2.getText();
            String c=t3.getText();
           
             String ddd=((JTextField)ch.getDateEditor().getUiComponent()).getText();
                       
            String e=t5.getText();
            String ff=t6.getText();
            String g=t7.getText();
            String h=t8.getText();
            String i=t9.getText();
            String j=t10.getText();
            String k=t11.getText();
            String l=(String)c1.getSelectedItem();
            String m=(String)c1.getSelectedItem();
         
          
            if(ae.getSource()== b){
                if(t1.getText().isEmpty() || t2.getText().isEmpty() || t3.getText().isEmpty() || ch.getDate().toString().isEmpty() || t5.getText().isEmpty() || t6.getText().isEmpty() || t7.getText().isEmpty() )
            {
                 
            
             JOptionPane.showMessageDialog(null,"all field requred !!");
                
               
           
            
            }
               else
                {
                    String eq="true";
                    if(v1.getText().equals(eq) && v2.getText().equals(eq) && v3.getText().equals(eq)  && v5.getText().equals(eq) && v6.getText().equals(eq) && v7.getText().equals(eq) && v8.getText().equals(eq) && v9.getText().equals(eq) && v10.getText().equals(eq) && v11.getText().equals(eq))
                    {
                   try{
                conn cc=new conn();
                 
                String q="insert into add_teacher values('"+a+"','"+bb+"','"+c+"','"+ddd+"','"+e+"','"+ff+"','"+g+"','"+h+"','"+i+"','"+j+"','"+k+"','"+l+"','"+m+"')";
                
             cc.s.executeUpdate(q);
               
                 JOptionPane.showMessageDialog(null,"Student Detail inserted Successfully");
                setVisible(false);
               
              
            }
            catch(Exception ee){
                System.out.println("the error is:"+ee);
            }     
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"input data invalid!!");
                   
                }
                }
            
            }
            if(ae.getSource()==b1){
            setVisible(false);
           // new Project().setVisible(true);
            }
        }
        
    public static void main(String[] args) {
         new AddTeacher().setVisible(true);
        
    }

  
    
}
