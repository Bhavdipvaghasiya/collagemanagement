package collage_management;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Student_Login extends JFrame implements ActionListener {
Container con;
Student_Login(){
  
    
    super("Collage management System");
    setLayout(new FlowLayout());
    con=getContentPane();
    
    Dimension dn = Toolkit.getDefaultToolkit().getScreenSize();
    int xx1=dn.width+this.getWidth();
    int yy1 = dn.height+this.getHeight();
    setSize(xx1,yy1);
    
    ImageIcon i2=new ImageIcon("C:\\Users\\kishan\\Documents\\NetBeansProjects\\collage_management\\src\\collage_management\\icon\\student.jpg");
     Image i1=i2.getImage().getScaledInstance(1030, 700,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i1);
     JLabel m1=new JLabel("",i3,JLabel.LEFT);
     
     m1.setBounds(0,0,1480,800);
     add(m1);
    
    
    JMenuBar mb=new JMenuBar();         
     JMenu exam =new JMenu("Examination");
    JMenuItem c1=new JMenuItem("Examination Detail");
  
    exam.setForeground(Color.BLUE);
    
    c1.setFont(new Font("monospace",Font.BOLD,16));
    c1.setMnemonic('H');
    c1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_H,ActionEvent.CTRL_MASK));
    c1.setBackground(Color.white);
     exam.add(c1);
    
    
    
     c1.addActionListener(this);
   
          
   
     JMenu fee =new JMenu("Payment Detail");
    JMenuItem s1=new JMenuItem("Fee Structure");
    JMenuItem s2=new JMenuItem("Student Fee Form");
   
    fee.setForeground(Color.BLUE);
    
    s1.setFont(new Font("monospace",Font.BOLD,16));
    s1.setMnemonic('L');
    s1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L,ActionEvent.CTRL_MASK));
    s1.setBackground(Color.white);
    fee.add(s1);
    
     s2.setFont(new Font("monospace",Font.BOLD,16));
    s2.setMnemonic('M');
    s2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M,ActionEvent.CTRL_MASK));
    s2.setBackground(Color.white);
    fee.add(s2);
    
     
    
     s1.addActionListener(this);
    s2.addActionListener(this);
    
     JMenu utility=new JMenu("Utility");
    JMenuItem k1=new JMenuItem("Notepad");
    JMenuItem k2=new JMenuItem("Calculater");
    JMenuItem k3=new JMenuItem("Library");
    utility.setForeground(Color.RED);
    
    k1.setFont(new Font("monospace",Font.BOLD,16));
    k1.setMnemonic('N');
    k1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,ActionEvent.CTRL_MASK));
    k1.setBackground(Color.white);
    utility.add(k1);
    
     k2.setFont(new Font("monospace",Font.BOLD,16));
    k2.setMnemonic('O');
    k2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,ActionEvent.CTRL_MASK));
    k2.setBackground(Color.white);
    utility.add(k2);
    
    k3.setFont(new Font("monospace",Font.BOLD,16));
    k3.setMnemonic('S');
    k3.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,ActionEvent.CTRL_MASK));
    k3.setBackground(Color.white);
    utility.add(k3);
    
     k1.addActionListener(this);
    k2.addActionListener(this);
    k3.addActionListener(this);
    
    JMenu about=new JMenu("About_Us");
    JMenuItem aa1=new JMenuItem("About Us");
    about.setForeground(Color.BLUE);
    
    aa1.setFont(new Font("monospace",Font.BOLD,16));
    aa1.setMnemonic('P');
    aa1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P,ActionEvent.CTRL_MASK));
    aa1.setBackground(Color.white);
    aa1.addActionListener(this);
    about.add(aa1);
    
      JMenu exit=new JMenu("Exit");
    JMenuItem e1=new JMenuItem("Exit");
    exit.setForeground(Color.RED);
    
   
    
    e1.setFont(new Font("monospace",Font.BOLD,16));
    e1.setMnemonic('Q');
    e1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,ActionEvent.CTRL_MASK));
    e1.setBackground(Color.white);
   e1.addActionListener(this);
    exit.add(e1);
    
    
    
   
    
    mb.add(exam);
  
    mb.add(fee);
    mb.add(utility);
    mb.add(about);
    mb.add(exit);
    con.add(mb);
    setJMenuBar(mb);
    
    setFont(new Font("Senserif",Font.BOLD,17));
    setLayout(new FlowLayout());
    setVisible(false);
}
    public void actionPerformed(ActionEvent ae){
        String msg=ae.getActionCommand();
        if(msg.equals("New Student")){
            
          new AddStudent().setVisible(true);
       
          
            
        }
         
         
        if(msg.equals("Student Detail")){
           new StudentDetail().setVisible(true);
            
        }
       
        
        
        if(msg.equals("Fee Structure")){
            new FeeStructure().setVisible(true);
            
        }
        if(msg.equals("Student Fee Form")){
          new FeeForm().setVisible(true);
            
        }
         
        if(msg.equals("Notepad")){
          try{
              Runtime.getRuntime().exec("notepad.exe");}
          catch(Exception e){}
        }
        
          if(msg.equals("Calculater")){
          try{
              Runtime.getRuntime().exec("calc.exe");}
          catch(Exception e){}
        }
        if(msg.equals("Exit")){
        System.exit(0);
            
        } 
        if(msg.equals("About Us")){
           new About_Us().setVisible(true);
            
        }
        if(msg.equals("Student Attendance")){
           new StudentAttendance().setVisible(true);
            
        }
       
        
        
        if(msg.equals("Examination Detail")){
            new Examination().setVisible(true);
            
        }
        
        if(msg.equals("Library")){
            new Library().setVisible(true);
            
        }
     
}

    public static void main(String[] args) {
      Student_Login l=  new Student_Login();
    l.setVisible(true);
    }
    
}
