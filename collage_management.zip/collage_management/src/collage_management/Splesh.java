
package collage_management;
import java.awt.*;
import javax.swing.*;

class myframe extends JFrame implements Runnable{
myframe(String s){
    super(s);
    setLayout(null);
    
  ImageIcon i2=new ImageIcon(getClass().getResource("/collage_management/icon/img2.jpg"));
        Image i1=i2.getImage().getScaledInstance(1400, 800,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i1);
 // ImageIcon i2=new ImageIcon(getClass().getResource("/collage_management/icon/img7.jpg"));
     JLabel m1=new JLabel("",i3,JLabel.LEFT);
     m1.setBounds(0,0,1500,800);
   
     
            
         add(m1);
        Thread t1=new  Thread(this);
         t1.start();
   
    }

  
    public void run(){
    try{
           Thread.sleep(5000);
            this.setVisible(false);
            Login f1=new Login();
        }catch(Exception e){
       
        
        }
}
}
        
        

public class Splesh {

   
    public static void main(String[] args) {
        myframe f=new myframe("jay swaminarayan");
        f.setVisible(true);
         int i;
        int x=1;
            for(i=2;i<=650;i+=4,x+=1){
                f.setLocation((390-((i+x)/2)),310-(i/2));
              f.setSize(i+5*x,i+x/3);
           
                    try{
                        Thread.sleep(10);
                        
                    }catch(Exception e){ }
    }
    }
    
}
