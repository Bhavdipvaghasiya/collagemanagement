
package collage_management;

import java.util.*;
import javax.swing.*;
import java.awt.event.*;


 class demo extends JFrame implements ActionListener{
	JButton b1;
	JTextField t1;
	JLabel l1;

	
	public demo(){
		setLayout(null);
		setSize(500,400);
		setLocation(200,100);
		
		l1=new JLabel("Password");
		l1.setBounds(50,50,150,30);
		add(l1);

		t1=new JTextField(10);
		t1.setBounds(150,50,150,30);
		add(t1);
                t1.addActionListener(this);

		b1=new JButton("Click");
		b1.setBounds(120,150,150,30);
		add(b1);
                b1.addActionListener(this);
	}

	public void actionPerformed(ActionEvent ae){
            String s=t1.getText();
           if(s.length()>=7){
            Boolean up=false,low=false,di=false,sp=false,wp=true;
                   if(ae.getSource()==b1){
                            if(s.isEmpty()){
                                    JOptionPane.showMessageDialog(null,"is empty");
                                    }
                            else {
                                
                                for(int j=0;j<s.length();j++){
                                    char c=s.charAt(j);
                                    
                                     if(Character.isDigit(c)){
                                          
                                     di=true;
                                     
                                     }
                                     
                                    else if(Character.isLowerCase(c)){
                                         
                                     low=true;
                                     }
                                     
                                    else if(Character.isUpperCase(c)){
                                         
                                     up=true;
                                     }
                                   
                                    else if(Character.isWhitespace(c)){
                                        wp=false;
                                     }
                                    else{
                                    sp=true;
                                    }
                                }
                                   
                                     if(up&&low&&di&&sp&&wp){
                                        JOptionPane.showMessageDialog(null,"arcitecter allow");
                                        System.exit(0);
                                     }
                                     else{
                                         if(wp==false){
                                          JOptionPane.showMessageDialog(null,"space not allow");
                                         }
                                         else{
                                      JOptionPane.showMessageDialog(null,"plase make stong password");
                                       System.exit(0);
                                      this.setVisible(false);
                                         }
                                     }
                                   }
                                     
                               
                               
                                }
                                
                            
                           
                                        
                                        
	}
            else{
                                         JOptionPane.showMessageDialog(null,"Plase enter Password Above 7 Charecter");
                                         t1.setText(null);
                                         t1.requestFocus();
                                        }
        }
        
	public static void main(String arg[]){
	new demo().setVisible(true);
}
}