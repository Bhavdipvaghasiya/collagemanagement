
package collage_management;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.border.EmptyBorder;

public class EnterMarks extends JFrame implements ActionListener {
   
    
     JLabel l1,l2,l3,l4,l5,l6;
     JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13;
     JButton b1;
     JComboBox c1,c2;
     Choice cc;
     public EnterMarks()
     {
          
          setSize(500,550);
         
          setLayout(null);
          Dimension dn =Toolkit.getDefaultToolkit().getScreenSize();
                int xx1=dn.width/2-this.getWidth()/2;
                int yy1=dn.height/2-this.getHeight()/2;
                setLocation(xx1,yy1);
          
        
          l1 = new JLabel("Enter Marks of Student");
          l1.setFont(new Font("serif",Font.BOLD,30));
          l1.setBounds(50,0,500,80);
          add(l1);
           l6 = new JLabel("Select Stream");
          l6.setBounds(5,60,100,40);
          add(l6);
          
          l5 = new JLabel("Select Semester");
          l5.setBounds(220,60,100,40);
          add(l5);
          
          String s12[]={"Btech","Bca","Bba","Bsc","Mba"};
           c2=new JComboBox(s12);
         c2.setBounds(100,70,100,20);
          add(c2);
          
          String s11[]={"1","2","3","4","5","6","7","8"};
          c1=new JComboBox(s11);
         c1.setBounds(320,70,100,20);
          add(c1);
          
         
          l2 = new JLabel("Enter Roll no");
          l2.setBounds(50,110,200,40);
          add(l2);
          cc=new Choice();
            cc.setForeground(Color.gray);
            cc.setBounds(250,120,150,20);
    cc.setFont(new Font("Trebuchet MS",Font.BOLD,14));
    
    try{
    conn c=new conn();
    ResultSet rs=c.s.executeQuery("select * from addstudent");
    while(rs.next()){
        
    cc.add(rs.getString("rollno"));
     }
    }
   
    catch(Exception e){}
//          String s1=(String)c2.getSelectedItem();
//          String s2=(String)c1.getSelectedItem();
//          if()
           add(cc);
          l3 = new JLabel("Enter Subject");
          //l3.setFont(new Font("serif",Font.BOLD,30));
          l3.setBounds(50,150,200,40);
          add(l3);
          
          l4 = new JLabel("Enter Marks of Student");
          //l4.setFont(new Font("serif",Font.BOLD,30));
          l4.setBounds(250,150,200,40);
          add(l4);
          
          t2=new JTextField();
          t2.setBounds(50,200,200,20);
          add(t2);
          
          t3=new JTextField();
          t3.setBounds(250,200,200,20);
          add(t3);
          
          t4=new JTextField();
          t4.setBounds(50,230,200,20);
          add(t4);
          
          t5=new JTextField();
          t5.setBounds(250,230,200,20);
          add(t5);
          
          t6=new JTextField();
          t6.setBounds(50,260,200,20);
          add(t6);
          
          t7=new JTextField();
          t7.setBounds(250,260,200,20);
          add(t7);
          
          t8=new JTextField();
          t8.setBounds(50,290,200,20);
          add(t8);
          
          t9=new JTextField();
          t9.setBounds(250,290,200,20);
          add(t9);
          
          t10=new JTextField();
          t10.setBounds(50,320,200,20);
          add(t10);
          
          t11=new JTextField();
          t11.setBounds(250,320,200,20);
          add(t11);
          
          b1= new JButton("Submit");
          b1.setBounds(50,360,100,30);
          b1.setBackground(Color.BLACK);
          b1.setForeground(Color.WHITE);
          
          b1.addActionListener(this);
          add(b1);
          
            ImageIcon i2=new ImageIcon(getClass().getResource("/collage_management/icon/st2.jpeg"));
        Image i1=i2.getImage().getScaledInstance(500, 550,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i1);
 
     JLabel m1=new JLabel("",i3,JLabel.LEFT);
     m1.setBounds(0,0,500,550);
     add(m1);
     }

    EnterMarks(String text) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
     public void actionPerformed(ActionEvent ae)
     {
       try{
       if(ae.getSource()== b1)
       {
        conn c11 = new conn();
         
        //String s1="insert into subject values('"+t1.getText()+"','"+t2.getText()+"','"+t3.getText()+"','"+t4.getText()+"','"+t5.getText()+"','"+t6.getText()+"','"+t7.getText()+"','"+t8.getText()+"','"+t9.getText()+"','"+t10.getText()+"','"+t11.getText()+"')";
       // String s2="insert into marks values('"+t1.getText()+"','"+t2.getText()+"','"+t3.getText()+"','"+t4.getText()+"','"+t5.getText()+"','"+t6.getText()+"','"+t7.getText()+"','"+t8.getText()+"','"+t9.getText()+"','"+t10.getText()+"','"+t11.getText()+"')";
        
         String s1="insert into subject values('"+c2.getSelectedItem()+"','"+c1.getSelectedItem()+"','"+cc.getSelectedItem()+"','"+t2.getText()+"','"+t4.getText()+"','"+t6.getText()+"','"+t8.getText()+"','"+t10.getText()+"')";
       String s2="insert into marks values('"+c2.getSelectedItem()+"','"+c1.getSelectedItem()+"','"+cc.getSelectedItem()+"','"+t3.getText()+"','"+t5.getText()+"','"+t7.getText()+"','"+t9.getText()+"','"+t11.getText()+"')";  
        c11.s.executeUpdate(s1);
        
         c11.s.executeUpdate(s2);
         
         JOptionPane.showMessageDialog(null,"Marks insert successfully");
         this.setVisible(false);
                 }
       
       }
       catch(Exception e)
       {
           System.out.println(e);
       }
     }
    public static void main(String[] args) {
        // TODO code application logic here
        new EnterMarks().setVisible(true);
    }
    
}
