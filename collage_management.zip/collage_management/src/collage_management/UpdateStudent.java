package collage_management;

import com.toedter.calendar.JDateChooser;
import java.sql.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UpdateStudent extends JFrame implements ActionListener{

   
    JLabel id,id1,id2,id3,id4,id5,id6,id7,id8,id9,id10,id11,id12,id15,lb,lb1,lb2;
    JTextField t,t1,t2,t3,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14;
    JButton b,b1,b2;
    String rollno;
    Choice c11;
    JComboBox c1,c2;
    JDateChooser ch;
     JLabel v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11;
    
    
    UpdateStudent(){
        
        setLayout(null);
        
        setSize(800,650);
        Dimension dn =Toolkit.getDefaultToolkit().getScreenSize();
                int xx1=dn.width/2-this.getWidth()/2;
                int yy1=dn.height/2-this.getHeight()/2;
                setLocation(xx1,yy1);
         
        JLabel l1=new JLabel("Enter rollno to Update the data of Student");
        l1.setBounds(50,90,400,50);
        l1.setFont(new Font("serif",Font.ITALIC| Font.BOLD,20));
        add(l1);
        
    c11=new Choice();
    c11.setForeground(new Color(23,45,75));
    c11.setFont(new Font("Trebuchet MS",Font.BOLD,14));
    
    try{
    conn c=new conn();
    
    ResultSet rs=c.s.executeQuery("select * from addstudent");
    
    while(rs.next()){
       
    c11.add(rs.getString("RollNo"));
    
    }
    }
   
    catch(Exception e){}
    
    
              
        c11.setBounds(500,100,100,30);
        add(c11);
        
        b2=new JButton("Update");
        b2.setBackground(Color.black);
        b2.setForeground(Color.white);
        b2.setBounds(650,100,100,30);
        add(b2);
        b2.addActionListener(this);
        
        id8=new JLabel("Update Teacher Details");
        id8.setBounds(250,10,400,50);
        id8.setFont(new Font("serif",Font.ITALIC,40));
        id8.setForeground(Color.black);
         add(id8);
        
            id2=new JLabel("Name");
            id2.setBounds(50,150,100,30);
            id2.setFont(new Font("serif",Font.BOLD,20));
            add(id2);
          
             v1= new JLabel("");
             v1.setBounds(200,175,100,30);
             v1.setForeground(Color.red);
            v1.setFont(new Font("serif",Font.BOLD,12));
             add(v1);
             
            t1=new JTextField();
            t1.setBounds(200,150,150,30);
            String vv1="^[a-zA-Z]{0,10}$";
            t1.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv1);
                     Matcher mt= pt.matcher(t1.getText());
                     
                     if(mt.matches())
                     {
                      
                       v1.setText("true");
                       v1.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v1.setText("No Match Validation");
                       
                       v1.setForeground(Color.red);
                     }
                   }
                   
            });
            add(t1);
            
            
            id3=new JLabel("Father Name");
            id3.setBounds(400,150,200,30);
            id3.setFont(new Font("serif",Font.BOLD,20));
             add(id3);
             
             v2= new JLabel("");
             v2.setBounds(600,175,100,30);
             v2.setForeground(Color.red);
            v2.setFont(new Font("serif",Font.BOLD,12));
             add(v2);
             
            t2=new JTextField();
            t2.setBounds(600,150,150,30);
            String vv2="^[a-zA-Z]{0,11}$";
            t2.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv2);
                     Matcher mt= pt.matcher(t2.getText());
                     
                     if(mt.matches())
                     {
                      
                       v2.setText("true");
                       v2.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v2.setText("No Match Validation");
                       
                       v2.setForeground(Color.red);
                     }
                   }
                   
            });
            add(t2);
            
            id4=new JLabel("Age");
            id4.setBounds(50,200,150,30);
            id4.setFont(new Font("serif",Font.BOLD,20));
             add(id4);
             
             v3= new JLabel("");
             v3.setBounds(200,225,100,30);
             v3.setForeground(Color.red);
            v3.setFont(new Font("serif",Font.BOLD,12));
             add(v3);
             
            t3=new JTextField();
            t3.setBounds(200,200,150,30);
            String vv3="^[0-9]{1,3}$";
            t3.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv3);
                     Matcher mt= pt.matcher(t3.getText());
                     
                     if(mt.matches())
                     {
                      
                       v3.setText("true");
                       v3.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v3.setText("No Match Validation");
                       
                       v3.setForeground(Color.red);
                     }
                   }
                   
            });
            add(t3);
            
            id5=new JLabel("DOB(dd/mm/yyyy)");
            id5.setBounds(400,200,200,30);
            id5.setFont(new Font("serif",Font.BOLD,20));
             add(id5);
             
              v4= new JLabel("");
             v4.setBounds(600,225,100,30);
             v4.setForeground(Color.red);
            v4.setFont(new Font("serif",Font.BOLD,12));
             add(v4);
             
             
           
             
             ch = new JDateChooser();
             ch.setBounds(600,200,150,30);
             ch.setDateFormatString("dd/MM/yyyy");
             
            add(ch);
            

                    
            id6=new JLabel("Address");
            id6.setBounds(50,250,100,30);
            id6.setFont(new Font("serif",Font.BOLD,20));
             add(id6);
             
             
              v5= new JLabel("");
             v5.setBounds(200,275,100,30);
             v5.setForeground(Color.red);
            v5.setFont(new Font("serif",Font.BOLD,12));
            add(v5);
             
            t5=new JTextField();
            t5.setBounds(200,250,150,30);
            String vv5="^[a-zA-Z]{0,50}$";
            
            t5.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv5);
                     Matcher mt= pt.matcher(t5.getText());
                     
                     if(mt.matches())
                     {
                      
                       v5.setText("true");
                       v5.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v5.setText("No Match Validation");
                       
                       v5.setForeground(Color.red);
                     }
                   }
                   
            });
            add(t5);
            
            id7=new JLabel("Mobileno");
            id7.setBounds(400,250,200,30);
            id7.setFont(new Font("serif",Font.BOLD,20));
             add(id7);
             
              v6= new JLabel("");
             v6.setBounds(600,275,100,30);
             v6.setForeground(Color.red);
            v6.setFont(new Font("serif",Font.BOLD,12));
             add(v6);
             
             
            t6=new JTextField();
            t6.setBounds(600,250,150,30);
            String vv6="^[0-9]{10,10}$";
            t6.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv6);
                     Matcher mt= pt.matcher(t6.getText());
                     
                     if(mt.matches())
                     {
                      
                       v6.setText("true");
                       v6.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v6.setText("No Match Validation");
                       
                       v6.setForeground(Color.red);
                     }
                   }
                   
            });
            add(t6);
            
            id8=new JLabel("Email Id");
            id8.setBounds(50,300,100,30);
            id8.setFont(new Font("serif",Font.BOLD,20));
             add(id8);
             
              v7= new JLabel("");
             v7.setBounds(200,325,100,30);
             v7.setForeground(Color.red);
            v7.setFont(new Font("serif",Font.BOLD,12));
             add(v7);
             
            t7=new JTextField();
            t7.setBounds(200,300,150,30);
            String vv7="^(.+)@(.+).(.+)$";
            t7.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv7);
                     Matcher mt= pt.matcher(t7.getText());
                     
                     if(mt.matches())
                     {
                      
                       v7.setText("true");
                       v7.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v7.setText("No Match Validation");
                       
                       v7.setForeground(Color.red);
                     }
                   }
                   
            });
            add(t7);
            
            id9=new JLabel("Class X(%)");
            id9.setBounds(400,300,130,30);
            id9.setFont(new Font("serif",Font.BOLD,20));
             add(id9);
             
              v8= new JLabel("");
             v8.setBounds(600,325,100,30);
             v8.setForeground(Color.red);
            v8.setFont(new Font("serif",Font.BOLD,12));
             add(v8);
             
            t8=new JTextField();
            t8.setBounds(600,300,150,30);
            String vv8="^[0-9]{0,2}[.][0-9]{0,2}$";
            t8.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv8);
                     Matcher mt= pt.matcher(t8.getText());
                     
                     if(mt.matches())
                     {
                      
                       v8.setText("true");
                       v8.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v8.setText("No Match Validation");
                       
                       v8.setForeground(Color.red);
                     }
                   }
                   
            });
            add(t8);
            
            id10=new JLabel("Class Xll(%)");
            id10.setBounds(50,350,150,30);
            id10.setFont(new Font("serif",Font.BOLD,20));
             add(id10);
             
              v9= new JLabel("");
             v9.setBounds(200,375,100,30);
             v9.setForeground(Color.red);
            v9.setFont(new Font("serif",Font.BOLD,12));
             add(v9);
             
            t9=new JTextField();
            t9.setBounds(200,350,150,30);
            String vv9="^[0-9]{0,2}[.][0-9]{0,2}$";
            t9.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv9);
                     Matcher mt= pt.matcher(t9.getText());
                     
                     if(mt.matches())
                     {
                      
                       v9.setText("true");
                       v9.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v9.setText("No Match Validation");
                       
                       v9.setForeground(Color.red);
                     }
                   }
                   
            });
            add(t9);
            
            id11=new JLabel("Aadhar NO");
            id11.setBounds(400,350,100,30);
            id11.setFont(new Font("serif",Font.BOLD,20));
             add(id11);
             
              v10= new JLabel("");
             v10.setBounds(600,375,100,30);
             v10.setForeground(Color.red);
            v10.setFont(new Font("serif",Font.BOLD,12));
             add(v10);
             
            t10=new JTextField();
            t10.setBounds(600,350,150,30);
            String vv10="^[0-9]{12,12}$";
            t10.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv10);
                     Matcher mt= pt.matcher(t10.getText());
                     
                     if(mt.matches())
                     {
                      
                       v10.setText("true");
                       v10.setForeground(Color.green);
                       
                     }
                     else
                     {
                       v10.setText("No Match Validation");
                       
                       v10.setForeground(Color.red);
                     }
                   }
                   
            });
            add(t10);
            
            id12=new JLabel("RollNO");
            id12.setBounds(50,400,150,30);
            id12.setFont(new Font("serif",Font.BOLD,20));
            add(id12);
             
              v11= new JLabel("");
             v11.setBounds(200,425,100,30);
             v11.setForeground(Color.red);
            v11.setFont(new Font("serif",Font.BOLD,12));
             add(v11);
             
            t11=new JTextField();
            t11.setBounds(200,400,150,30);
            String vv11="^[0-9]{0,4}$";
            t11.addKeyListener(new KeyAdapter(){
                   public void keyReleased(KeyEvent ke)
                   {
                     
                     Pattern pt= Pattern.compile(vv11);
                     Matcher mt= pt.matcher(t11.getText());
                     
                     if(mt.matches())
                     {
                      
                       v11.setText("true");
                       v11.setForeground(Color.green);
                      
                     }
                     else
                     {
                       v11.setText("No Match Validation");
                       
                       v11.setForeground(Color.red);
                     }
                   }
                   
            });
            add(t11);
            
            lb=new JLabel("Cource");
            lb.setBounds(400,400,150,30);
            lb.setFont(new Font("serif",Font.BOLD,20));
             add(lb);
             
            String cource[] = {"Bca","Bsc-It","Bsc"};
            c1=new JComboBox(cource);
            c1.setBackground(Color.white);
            c1.setBounds(600,400,150,30);
            add(c1);
            
            lb1=new JLabel("Brance");
             lb1.setBounds(50,450,150,30);
            lb1.setFont(new Font("serif",Font.BOLD,20));
             add(lb1);
             
             String branch[]={"Computer","science"};
             c2=new JComboBox(branch);
             c2.setBackground(Color.white);
            c2.setBounds(200,450,150,30);
             add(c2);
             
             b=new JButton("Submit");
             b.setBackground(Color.BLACK);
             b.setForeground(Color.white);
             b.setBounds(250,550,150,40);
             add(b);
             
             
             
             b1=new JButton("Cancle");
             b1.setBackground(Color.BLACK);
             b1.setForeground(Color.white);
             b1.setBounds(450,550,150,40);
             add(b1);
             
             b.addActionListener(this);
             b1.addActionListener(this);

             ImageIcon i2=new ImageIcon(getClass().getResource("/collage_management/icon/st1.jpeg"));
        Image i1=i2.getImage().getScaledInstance(900, 650,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i1);
 
     JLabel m1=new JLabel("",i3,JLabel.LEFT);
     m1.setBounds(0,0,900,650);
     add(m1);
       setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
    if(ae.getSource()==b){
        if(t1.getText().isEmpty() || t2.getText().isEmpty() || t3.getText().isEmpty() || ch.getDate().toString().isEmpty() || t5.getText().isEmpty() || t6.getText().isEmpty() || t7.getText().isEmpty() )
            {
                 
            
             JOptionPane.showMessageDialog(null,"all field requred !!");
                
               
           
            
            }
               else
                {
                    String eq="true";
                    if(v1.getText().equals(eq) && v2.getText().equals(eq) && v3.getText().equals(eq)  && v5.getText().equals(eq) && v6.getText().equals(eq) && v7.getText().equals(eq) && v8.getText().equals(eq) && v9.getText().equals(eq) && v10.getText().equals(eq) && v11.getText().equals(eq))
                    {
    try{
    conn con=new conn();
     String dod=((JTextField)ch.getDateEditor().getUiComponent()).getText();
    String str="update addstudent set name='"+t1.getText()+"',fathers_name='"+t2.getText()+"',age='"+t3.getText()+"',dob='"+dod+"',address='"+t5.getText()+"',phone='"+t6.getText()+"',email='"+t7.getText()+"',class_x='"+t8.getText()+"',class_xii='"+t9.getText()+"',aadhar='"+t10.getText()+"',rollno='"+t11.getText()+"',course='"+c1.getSelectedItem()+"',branch='"+c2.getSelectedItem()+"'";

    con.s.executeUpdate(str);
    JOptionPane.showMessageDialog(null,"Successfully Update");
    setVisible(false);
    new StudentDetail().setVisible(true);
    
    }catch(Exception e){
        System.out.println(e);
    }
                    }
                    else{
                      JOptionPane.showMessageDialog(null,"input data invalid");
                    }
                }
    }
    if(ae.getSource()==b1){
    setVisible(false);
  //  new Project().setVisible(true);
    
    }
    if(ae.getSource()==b2){
        
    v1.setText("true");
    v1.setForeground(Color.CYAN);
    v2.setText("true");
    v2.setForeground(Color.CYAN);
    v3.setText("true");
    v3.setForeground(Color.CYAN);
    v4.setText("true");
    v4.setForeground(Color.CYAN);
    v5.setText("true");
    v5.setForeground(Color.CYAN);
    v6.setText("true");
    v6.setForeground(Color.CYAN);
    v7.setText("true");
    v7.setForeground(Color.CYAN);
    v8.setText("true");
    v8.setForeground(Color.CYAN);
    v9.setText("true");
    v9.setForeground(Color.CYAN);
    v10.setText("true");
    v10.setForeground(Color.CYAN);
    v11.setText("true");
    v11.setForeground(Color.CYAN);
        try{
    conn con=new conn();
    String str="select * from addstudent where rollno='"+c11.getSelectedItem()+"'";
    ResultSet rs=con.s.executeQuery(str);
    if(rs.next()){
        //f.setVisible(true);
        
        t1.setText(rs.getString(1));
        t2.setText(rs.getString(2));
        t3.setText(rs.getString(3));
        
        
        String ddd=(rs.getString(4));
        
        ((JTextField)ch.getDateEditor().getUiComponent()).setText(ddd);
        
        t5.setText(rs.getString(5));
        t6.setText(rs.getString(6));
        t7.setText(rs.getString(7));
        t8.setText(rs.getString(8));
        t9.setText(rs.getString(9));
        t10.setText(rs.getString(10));
        t11.setText(rs.getString(11));
        t13.setText(rs.getString(12));
        t14.setText(rs.getString(13));
    
    }
    }
    catch(Exception e){}
   
    }
    }
    public static void main(String[] args) {
            new UpdateStudent().setVisible(true);
            
    }

}
