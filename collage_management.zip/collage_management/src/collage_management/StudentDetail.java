
package collage_management;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;


public class StudentDetail extends JFrame implements ActionListener{
        JLabel l1,l2,l3;
        JTable t1;
        JButton b1,b2,b3;
        JTextField t2;
        String x[]={"Name","Father Name","Age","Date of Birth","Address","Phone","Email","Class X(%)","Class XII(%)","Adhar No","Roll no","Course","Branch"};
        String y[][]=new String[20][13];
        int i=0,j=0;
		          
        StudentDetail(){
            
            super ("Student Details");
            
            
            
            Dimension dn =Toolkit.getDefaultToolkit().getScreenSize();
                int xx1=dn.width+this.getWidth();
                int yy1=dn.height+this.getHeight();
                setSize(xx1,yy1);
                setLayout(null);
                
             
                
                
            
            l1=new JLabel("Enter Rollno to Delete addstudent:");
            l1.setBounds(50,360,400,30);
            l1.setFont(new Font("serif",Font.BOLD,20));
            add(l1);
            
            t2=new JTextField();
            t2.setBounds(400,360,200,30);
            add(t2);
            
             b1=new JButton("Delete");
            b1.setBackground(Color.black);
            b1.setForeground(Color.white);
            b1.setBounds(620,360,100,30);
            add(b1);
            
            l2=new JLabel("Add New Students:");
            l2.setBounds(50,450,400,30);
            l2.setFont(new Font("serif",Font.BOLD,20));
            add(l2);
            
            b2=new JButton("Add Student");
            b2.setBackground(Color.black);
            b2.setForeground(Color.white);
            b2.setBounds(300,450,150,30);
            add(b2);
            
             l3=new JLabel("Update Students Detail:");
            l3.setBounds(50,490,400,30);
            l3.setFont(new Font("serif",Font.BOLD,20));
            add(l3);
            
            b3=new JButton("Update Student");
            b3.setBackground(Color.black);
            b3.setForeground(Color.white);
            b3.setBounds(300,490,150,30);
            add(b3);
            
            b1.addActionListener(this);
            b2.addActionListener(this);
            b3.addActionListener(this);
            
            try{
                
               
        
                String s1="select * from addstudent";
                conn c1=new conn();
                ResultSet rs=c1.s.executeQuery(s1);
                while(rs.next()){
                y[i][j++]=rs.getString(1);
                y[i][j++]=rs.getString(2);
                y[i][j++]=rs.getString(3);
                y[i][j++]=rs.getString(4);
                y[i][j++]=rs.getString(5);
                y[i][j++]=rs.getString(6);
                y[i][j++]=rs.getString(7);
                y[i][j++]=rs.getString(8);
                y[i][j++]=rs.getString(9);
                y[i][j++]=rs.getString(10);
                y[i][j++]=rs.getString(11);  
                y[i][j++]=rs.getString(12);
                y[i][j++]=rs.getString(13);
       
                i++;
                j=0;
                }t1=new JTable(y,x);
                
            }
            catch(Exception e){
            
            }
            JScrollPane sp=new JScrollPane(t1);
            sp.setBounds(20,20,1200,330);
            add(sp);
            getContentPane().setBackground(Color.white)            ;
            t1.setEnabled(false);
          //  b1.addActionListener(this);
            
        }
        public void actionPerformed(ActionEvent ae){
      
        if(ae.getSource()==b1){
        try{
            conn c=new conn();
        String a=t2.getText();
        String q="delete from addstudent where rollno='"+a+"'";
        c.s.executeUpdate(q);
        this.setVisible(false);
        new StudentDetail().setVisible(true);
        
        }catch(Exception e){}
        
        }
        if(ae.getSource()==b2){
        new AddStudent().setVisible(true);
        this.setVisible(false);
        
        }
        if(ae.getSource()==b3){
        new UpdateStudent().setVisible(true);
        this.setVisible(false);
        }
        }
    
    public static void main(String[] args) {
      new StudentDetail().setVisible(true);
      
    }
    
}
