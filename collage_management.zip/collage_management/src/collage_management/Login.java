package collage_management;


 import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

   

public class Login extends JFrame implements ActionListener {
  
    JLabel l1,l2,l3,l4,l5;
    JTextField t1;
    JPasswordField t2;
    JButton b1,b2;
    JCheckBox b3;
    JComboBox c1;
    
  //  Container con;
    
    
    Login(){
        super ("Login");
        setBackground(Color.CYAN);
        //con=getContentPane();
        setLayout(null);
     
      
       l5= new JLabel("LOGIN");
       l5.setBounds(170,5,130,40);
       l5.setForeground(Color.cyan);
       l5.setFont(new Font("serif" ,Font.BOLD,20));
       add(l5);
        
        l1=new JLabel("Username");
        l1.setForeground(Color.cyan);
       l1.setFont(new Font("serif" ,Font.BOLD,20));
         l1.setBounds(60,50,100,30);
        add(l1);
        t1=new JTextField(10);
          t1.setBorder(null);
          t1.setBounds(170,50,150,25);
         add(t1);
         
         l2=new JLabel("Password");
          l2.setForeground(Color.cyan);
          l2.setFont(new Font("serif" ,Font.BOLD,20));
          l2.setBounds(60,100,100,30);
          
        add(l2);
        t2=new JPasswordField(10);
        t2.setBorder(null);
      
         t2.setBounds(170,100,150,25);
         t2.setEchoChar('*');
         add(t2);
          
         b3= new JCheckBox();
         b3.setBounds(330,100,18,18);
         
         b3.addActionListener(this);
         add(b3);
         
         l3=new JLabel("show");
         l3.setForeground(Color.cyan);
         l3.setBounds(360,100,120,20);
         add(l3);
         
          
         l4=new JLabel("Designation");
          l4.setForeground(Color.cyan);
          
          l4.setFont(new Font("serif" ,Font.BOLD,20));
          l4.setBounds(60,150,100,30);
          
        add(l4);
        String s11[]={"Admin","Teacher","Student"};
        c1=new JComboBox(s11);
        c1.setBounds(170,150,150,25);
         c1.setBorder(null);
         c1.setBackground(Color.cyan);
        add(c1);
         
        
        
         b1=new JButton("Login");
         b1.setBorderPainted(false);
          b1.setBounds(65, 200, 120, 30);
         b1.setFont(new Font("serif",Font.BOLD,15));
         b1.addActionListener(this);
         add(b1);
         
         b2=new JButton("Cancel");
         b2.setBorderPainted(false);
         b2.setFont(new Font("serif",Font.BOLD,15));
         b2.addActionListener(this);
         b2.setBounds(205,200,120,30);
         add(b2);
            
       ImageIcon c1 = new ImageIcon("C:\\Users\\kishan\\Documents\\NetBeansProjects\\collage_management\\src\\collage_management\\icon\\login.jpg");
        Image i1=c1.getImage().getScaledInstance(600, 300,Image.SCALE_DEFAULT);
        ImageIcon i2=new ImageIcon(i1);
          JLabel m1=new JLabel("",i2,JLabel.LEFT);
          m1.setBounds(0,0,500,300);
           add(m1);
        setVisible(true);
        setSize(430,330);
       Dimension dn =Toolkit.getDefaultToolkit().getScreenSize();
                int xx1=dn.width/2-this.getWidth()/2;
                int yy1=dn.height/2-this.getHeight()/2;
                setLocation(xx1,yy1);
        
        
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==b3)
        {
           if(l3.getText()=="show")
           {
             t2.setEchoChar((char)0);
             l3.setText("hide");
           }
           else
           {
             t2.setEchoChar('*');
             l3.setText("show");
           }
        }
        
        if(ae.getSource()==b1){
        try{
            
            conn con=new conn();
            String u=t1.getText();
            String v=t2.getText();
            String l=(String)c1.getSelectedItem();
                        if(l.equals("Admin")){
                        String q="select * from Login where Username='"+u+"' and Password='"+v+"'";


                       ResultSet rs=con.s.executeQuery(q); 
                       
                        if(rs.next()){

                        new Project().setVisible(true);
                        setVisible(false);

                        }
            }
            
             else if(l.equals("Teacher")){
             String q2="select * from T_Log where username='"+u+"' and password='"+v+"'";
           
            
           ResultSet rs2=con.s.executeQuery(q2); 
            
            if(rs2.next()){
             
            new Teacher_Login().setVisible(true);
            setVisible(false);
            }}
             else if(l.equals("Student")){
             String q1="select * from S_Log where username="+u+"' and password='"+v+"'";
           
            
           ResultSet rs=con.s.executeQuery(q1); 
            
            if(rs.next()){
             
            new Student_Login().setVisible(true);
            setVisible(false);
            }}
            else{
                
                          JOptionPane.showMessageDialog(null,"Invalide Password");
                          /*JOptionPane.showConfirmDialog(null,"hello");
                          JOptionPane.showInputDialog(null,"kay nay");
                          String [] options={"abc","def","ghk"};
                          int x = JOptionPane.showOptionDialog(null, "Returns the position of your choice on the array",
                "Click a button",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
        System.out.println(x);*/
                            
           // setVisible(false);
            
            
            }   
        }catch(Exception e){
            System.out.println(e);
        }
    
        }
         if(ae.getSource()==b2){
                this.setVisible(false);
    }
        }
    
   

    public static void main(String[] args) {
        Login lp=new Login();
        
    
    }    
}
