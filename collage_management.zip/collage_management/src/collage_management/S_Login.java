
package collage_management;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.sql.*;
import java.util.regex.*;


public class S_Login extends JFrame implements ActionListener{

    


    private  JPanel contentPane;
   public JTextField t1;
   JPasswordField t2,t3;
    JCheckBox b3,b4;
   JLabel l11,l12,v1,v2;
  
    JButton b1,b2;
    Choice c1;  
   

  
   public S_Login(){
    contentPane=new JPanel();
    contentPane.setBorder(new EmptyBorder(5,5,5,5));
    setContentPane(contentPane);
    contentPane.setLayout(null);
    setSize(450,400);
    Dimension din=Toolkit.getDefaultToolkit().getScreenSize();
            int x=din.width/2-this.getWidth()/2;
            int y=din.height/2-this.getHeight()/2;
            setLocation(x,y);
            setResizable(false);
    
    c1=new Choice();
    c1.setForeground(new Color(23,45,75));
    c1.setFont(new Font("Trebuchet MS",Font.BOLD,14));
    
    try{
    conn c=new conn();
    ResultSet rs=c.s.executeQuery("select * from addstudent");
    while(rs.next()){
    c1.add(rs.getString("Rollno"));
    }
    }
   
    catch(Exception e){}
    
    JLabel l1=new JLabel("Select Name");
    l1.setForeground(new Color(23,45,17));
    l1.setFont(new Font("Tahoma",Font.BOLD,14));
    l1.setBounds(64,63,102,32);
    contentPane.add(l1);
    
     JLabel l2=new JLabel("UserName");
    l2.setForeground(new Color(25,25,112));
    l2.setFont(new Font("Tahoma",Font.BOLD,14));
    l2.setBounds(64,100,102,22);
    contentPane.add(l2);
    
     JLabel l3=new JLabel("Password");
    l3.setForeground(new Color(23,55,17));
    l3.setFont(new Font("Tahoma",Font.BOLD,14));
    l3.setBounds(64,140,102,22);
    contentPane.add(l3);
    
     JLabel l4=new JLabel("Confim");
    l4.setForeground(new Color(43,55,17));
    l4.setFont(new Font("Tahoma",Font.BOLD,14));
    l4.setBounds(64,180,102,22);
    contentPane.add(l4);
    
       
    c1.setBounds(174,66,156,20);
    contentPane.add(c1);
    v2=new JLabel();
      v2.setForeground(Color.red);
    v2.setFont(new Font("Tahoma",Font.BOLD,12));
    v2.setBounds(174,115,200,22);
    contentPane.add(v2);

    t1=new JTextField();
    t1.setForeground(new Color(34,65,86));
    t1.setFont(new Font("Trebuchat MS",Font.BOLD,14));
    t1.setColumns(10);
    t1.setBounds(174,100,156,20);
     String st2="^[a-zA-Z]\\w{5,29}$";
    t1.addKeyListener(new KeyAdapter(){
        public void keyReleased(KeyEvent ke){
            Pattern pt=Pattern.compile(st2);
            Matcher mt=pt.matcher(t1.getText());
            if(mt.matches()){
             v2.setText("true");
            v2.setForeground(Color.green);
            }
            else{
            v2.setText("Input Strong Password");
            v2.setForeground(Color.red);
            }
        }
    });
    contentPane.add(t1);
  
     v1=new JLabel();
      v1.setForeground(Color.red);
    v1.setFont(new Font("Tahoma",Font.BOLD,12));
    v1.setBounds(174,155,200,22);
    contentPane.add(v1);
    t2=new JPasswordField();
    t2.setForeground(new Color(34,65,86));
    t2.setFont(new Font("Trebuchat MS",Font.BOLD,14));
    t2.setColumns(10);
    
    t2.setBounds(174,140,156,20);
    t2.setEchoChar('*');
   
 String st1="^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,20}$";
    t2.addKeyListener(new KeyAdapter(){
        public void keyReleased(KeyEvent ke){
            Pattern pt=Pattern.compile(st1);
            Matcher mt=pt.matcher(t2.getText());
            if(mt.matches()){
             v1.setText("true");
            v1.setForeground(Color.green);
            }
            else{
            v1.setText("Input Strong Password");
            v1.setForeground(Color.red);
            }
        }
    });
    contentPane.add(t2);
    
      b3= new JCheckBox();
         b3.setBounds(330,140,18,18);
         b3.addActionListener(this);
         add(b3);
         
         l11=new JLabel("show");
         l11.setBounds(360,140,120,20);
         add(l11);
         
       
    
    t3=new JPasswordField();
    
    t3.setForeground(new Color(34,65,86));
    t3.setFont(new Font("Trebuchat MS",Font.BOLD,14));
    t3.setColumns(10);
    t3.setEchoChar('*');
    t3.setBounds(174,180,156,20);
    contentPane.add(t3);
    
      b4= new JCheckBox();
         b4.setBounds(330,180,18,18);
         b4.addActionListener(this);
         add(b4);
         
         l12=new JLabel("show");
         l12.setBounds(360,180,120,20);
         add(l12);
         
    
     
    
    try{
    conn c=new conn();
    ResultSet rs=c.s.executeQuery("select * from addstudent where emp_id='"+c1.getSelectedItem()+"'");
    while(rs.next()){
    t2.setText(rs.getString("name"));
   
    
    }
    }
    catch(Exception e){}
  
    
  
   
    
    b1=new JButton ("Save");
    b1.addActionListener(this);
    b1.setForeground(Color.black);
    b1.setFont(new Font("Trebuchet MS",Font.BOLD,14));
    b1.setBounds(64,210,111,33);
    b1.setBackground(Color.white);
     contentPane.add(b1);
   
   b2=new JButton ("Back");
  
    b2.setFont(new Font("Trebuchet MS",Font.BOLD,14));
    b2.setBounds(198,210,111,33);
    b2.setBackground(Color.white);
      b2.setForeground(Color.black);
    b2.addActionListener(this);
    contentPane.add(b2);
    
     
    
     
    
    JPanel panel=new JPanel();
    panel.setBorder(new TitledBorder(new LineBorder(new Color(102,205,170),2,true),"Student Login ",TitledBorder.LEADING,TitledBorder.TOP,null,new Color(30,144,255)));
    panel.setBackground(new Color(34,56,255));
    panel.setBounds(10,30,390,280);
    
    contentPane.setBackground(Color.white);
    panel.setBackground(Color.white);
    contentPane.add(panel);
    
     
    }
    public void actionPerformed(ActionEvent ae){
    
        if(ae.getSource()==b3)
        {
      if(l11.getText()=="show")
           {
             t2.setEchoChar((char)0);
             l11.setText("hide");
           }
           else
           {
             t2.setEchoChar('*');
             l11.setText("show");
           }
        }
        
        
        if(ae.getSource()==b4)
        {
      if(l12.getText()=="show")
           {
             t3.setEchoChar((char)0);
             l12.setText("hide");
           }
           else
           {
             t3.setEchoChar('*');
             l12.setText("show");
           }
        }
        
    if(ae.getSource()==b1){
        String s11=t3.getText();
        if(t1.getText().isEmpty()||t2.getText().isEmpty()){
        JOptionPane.showMessageDialog(null,"Blank Filled Required");
        }
        else{
            String ch="true";
            String vv2=v2.getText();

            String vv1=v1.getText();
                if(vv1.equals(ch)&&vv2.equals(ch))
                {
                    if(s11.equals(t2.getText())){
                        try{
                             conn con=new conn();
            
                            String  s1="insert into S_Log values(?,?)";
                            PreparedStatement st=con.c.prepareStatement(s1);
                            st.setString(1,t1.getText());
                            st.setString(2,t2.getText());



                            int i=st.executeUpdate();
                            if(i>0){
                            JOptionPane.showMessageDialog(null,"Successfully paid");

                             new Login().setVisible(true);
                            this.setVisible(false);
                               
                            }
                            else{
                            JOptionPane.showMessageDialog(null,"Error");

                            }
                            }catch(Exception e){System.out.print(e); }
            
            
                        }
                        else{
                         JOptionPane.showMessageDialog(null,"eneter pasword not match");
                        }
       
                }
        }
    }
    if(ae.getSource()==b2){
            this.setVisible(false);}
  
    }
    public static void main(String[] args) {
        new S_Login().setVisible(true);
    }
    
}
