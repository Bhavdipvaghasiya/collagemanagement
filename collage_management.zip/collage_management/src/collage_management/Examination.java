
package collage_management;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import net.proteanit.sql.DbUtils;
import javax.swing.border.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
   
public class Examination extends JFrame implements ActionListener {
   private JPanel contentPane;
   private JTable table;
   private JTextField search;
   private JButton b1,b2,b3,b4;
    
   public void Book()
   {
           try{
             conn con= new conn();
             String sql="select * from addstudent";
             PreparedStatement st= con.c.prepareStatement(sql);
             ResultSet rs= st.executeQuery();
           table.setModel(DbUtils.resultSetToTableModel(rs));
               
             rs.close();
             st.close();
            con.c.close();
             
   }
          catch(Exception e)
          {
          
          }
   }
 public Examination()
         
         
 {  
     
     Dimension dn =Toolkit.getDefaultToolkit().getScreenSize();
            int x1 = dn.width+this.getWidth();
            int y1 = dn.height+this.getHeight();
            setSize(x1,y1);
            
            
   
   contentPane=new JPanel();
   contentPane.setBackground(Color.white);
   contentPane.setBorder(new EmptyBorder(5,5,5,5));
   setContentPane(contentPane);
   contentPane.setLayout(null);
   JScrollPane scrollpane= new JScrollPane();
   scrollpane.setBounds(35,133,x1-80,y1-305);
   contentPane.add(scrollpane);
   
   table = new JTable();
  
   table.addMouseListener(new MouseAdapter()
           {
            public void mouseClicked(MouseEvent arg0)
            {
              int row=table.getSelectedRow();
              setBackground( new Color(255, 165, 12));
              search.setText(table.getModel().getValueAt(row, 10).toString());
          
            }
            
           });
                 
            
           table.setBackground( new Color(255, 165, 0));
           table.setForeground(Color.white);
           table.setFont(new Font("Trebuchet MS",Font.BOLD,16));
           scrollpane.setViewportView(table);
           
           b1= new JButton("result");
           b1.addActionListener(this);
           b1.setBorder(new LineBorder(new Color(0,0,0),2,true));
           b1.setForeground(Color.white);
           b1.setBounds(650,89,70,33);
           b1.setBackground(new Color(255, 165, 0));
           b1.setFont(new Font("Trebuchet MS",Font.BOLD,16));
           contentPane.add(b1);
           
           JLabel l1= new JLabel("chack result");
           l1.setForeground(new Color(255, 165, 0));
           
           l1.setFont(new Font("Trebuchet MS",Font.ITALIC,30));
           l1.setBounds(400,15,400,47);   
           contentPane.add(l1);
           
           
           search= new JTextField();
            search.setBackground(new Color(255, 165, 0));
           search.setForeground(Color.white);
            search.setBorder(new LineBorder(new Color(0,0,0),2,true));
           search.setFont(new Font("Trebuchet MS",Font.BOLD|Font.ITALIC,16));
            search.setBounds(390,89,250,33); 
            search.setColumns(10);
            contentPane.add(search);
            
            
            JLabel l3= new JLabel("back");
            l3.addMouseListener(new MouseAdapter()
           {
             public void mouseClicked(MouseEvent arg0)
            {
             
              
            }
            
           });
             l3.setForeground(new Color(255, 165, 0));
             
              l3.setFont(new Font("Trebuchet MS",Font.BOLD|Font.ITALIC,16));
              
            l3.setBounds(197,89,72,33);
            l3.setBorder(new LineBorder(new Color(255, 165, 0),2,true));
             contentPane.add(l3);
             
             JPanel panel = new JPanel();
             panel.setBorder(new TitledBorder(new LineBorder(Color.GREEN,3,true),"book details",
                     TitledBorder.LEADING,TitledBorder.TOP,null,new Color(0,128,0)));
             panel.setBounds(20,54,x1-50,y1-200);
             panel.setBackground(Color.white);
            
             contentPane.add(panel);
            // search.setBackground( Color.CYAN);
             Book();
                 
            
            
                
             
 }
 
 public void actionPerformed(ActionEvent ae)
 {
    try{
      conn con= new conn();
      if(ae.getSource()== b1)
      {
       new Marks(search.getText()).setVisible(true);
       
       this .setVisible(false);
      };
    }
    catch(Exception e)
    {
    
    }
    
 }
    
    public static void main(String[] args) {
       
        new Examination().setVisible(true);
        
        
    }
    
}
