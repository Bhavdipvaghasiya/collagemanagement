
package collage_management;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Project extends JFrame implements ActionListener {
      Container con;
Project(){
  
    
    super("Collage management System");
    setLayout(new FlowLayout());
    con=getContentPane();
    Dimension dn =Toolkit.getDefaultToolkit().getScreenSize();
                int xx1=dn.width+this.getWidth();
                int yy1=dn.height+this.getHeight();
                setSize(xx1,yy1);
    
    
    ImageIcon i2=new ImageIcon(getClass().getResource("/collage_management/icon/img2.jpg"));
     Image i1=i2.getImage().getScaledInstance(1350, 700,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i1);
     JLabel m1=new JLabel("",i3,JLabel.LEFT);
     
     m1.setBounds(0,0,1480,800);
     add(m1);
    
    
    JMenuBar mb=new JMenuBar();
    JMenu master =new JMenu("Master");
    JMenuItem m11=new JMenuItem("New Faculty");
    JMenuItem m2=new JMenuItem("New Student");
    JMenuItem m12=new JMenuItem("Teacher Login");
    JMenuItem m22=new JMenuItem("Student Login");
    master.setForeground(Color.BLUE);
        
    m11.setFont(new Font("monospace",Font.BOLD,16));
    m11.setMnemonic('A');
    m11.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,ActionEvent.CTRL_MASK));
    m11.setBackground(Color.white);
    master.add(m11);
    
     m2.setFont(new Font("monospace",Font.BOLD,16));
    m2.setMnemonic('B');
    m2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B,ActionEvent.CTRL_MASK));
    m2.setBackground(Color.white);
    master.add(m2);
     m12.setFont(new Font("monospace",Font.BOLD,16));
  
    m12.setBackground(Color.white);
    master.add(m12);
    
     m22.setFont(new Font("monospace",Font.BOLD,16));
   
    m22.setBackground(Color.white);
    master.add(m22);
    
    m12.addActionListener(this);
    m22.addActionListener(this);
    
    m11.addActionListener(this);
    m2.addActionListener(this);
    
     JMenu user =new JMenu("Detail");
    JMenuItem u1=new JMenuItem("Student Detail");
    JMenuItem u2=new JMenuItem("Teacher Detail");
    user.setForeground(Color.RED);
    
    u1.setFont(new Font("monospace",Font.BOLD,16));
    u1.setMnemonic('C');
    u1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,ActionEvent.CTRL_MASK));
    u1.setBackground(Color.white);
    user.add(u1);
    
     u2.setFont(new Font("monospace",Font.BOLD,16));
    u2.setMnemonic('D');
    u2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D,ActionEvent.CTRL_MASK));
    u2.setBackground(Color.white);
    user.add(u2);
    
     u1.addActionListener(this);
    u2.addActionListener(this);
    
     JMenu attendance =new JMenu("Attendance");
    JMenuItem b1=new JMenuItem("Student Attendance");
    JMenuItem b2=new JMenuItem("Teacher Attendance");
    attendance.setForeground(Color.BLUE);
    
    b1.setFont(new Font("monospace",Font.BOLD,16));
    b1.setMnemonic('E');
    b1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E,ActionEvent.CTRL_MASK));
    b1.setBackground(Color.white);
    attendance.add(b1);
    
     b2.setFont(new Font("monospace",Font.BOLD,16));
    b2.setMnemonic('R');
    b2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R,ActionEvent.CTRL_MASK));
    b2.setBackground(Color.white);
    attendance.add(b2);
    
     b1.addActionListener(this);
    b2.addActionListener(this);
    
     JMenu attendance_detail=new JMenu("Attendance Detail");
    JMenuItem a1=new JMenuItem("Student Attendance Detail");
    JMenuItem a2=new JMenuItem("Teacher Attendance Detail");
    attendance_detail.setForeground(Color.RED);
    
    a1.setFont(new Font("monospace",Font.BOLD,16));
    a1.setMnemonic('F');
    a1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F,ActionEvent.CTRL_MASK));
    a1.setBackground(Color.white);
    attendance_detail.add(a1);
    
     a2.setFont(new Font("monospace",Font.BOLD,16));
    a2.setMnemonic('G');
    a2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G,ActionEvent.CTRL_MASK));
    a2.setBackground(Color.white);
    attendance_detail.add(a2);
    
     a1.addActionListener(this);
    a2.addActionListener(this);
    
     JMenu exam =new JMenu("Examination");
    JMenuItem c1=new JMenuItem("Examination Detail");
    JMenuItem c2=new JMenuItem("Enter Mark");
    exam.setForeground(Color.BLUE);
    
    c1.setFont(new Font("monospace",Font.BOLD,16));
    c1.setMnemonic('H');
    c1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_H,ActionEvent.CTRL_MASK));
    c1.setBackground(Color.white);
     exam.add(c1);
    
     c2.setFont(new Font("monospace",Font.BOLD,16));
    c2.setMnemonic('I');
    c2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_I,ActionEvent.CTRL_MASK));
    c2.setBackground(Color.white);
    exam.add(c2);
    
     c1.addActionListener(this);
    c2.addActionListener(this);
       
     JMenu report =new JMenu("Update Detail");
    JMenuItem r1=new JMenuItem("Update Student Detail");
    JMenuItem r2=new JMenuItem("Update Teacher Detail");
    report.setForeground(Color.RED);
    
    r1.setFont(new Font("monospace",Font.BOLD,16));
    r1.setMnemonic('J');
    r1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_J,ActionEvent.CTRL_MASK));
    r1.setBackground(Color.white);
    report.add(r1);
    
     r2.setFont(new Font("monospace",Font.BOLD,16));
    r2.setMnemonic('K');
    r2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_K,ActionEvent.CTRL_MASK));
    r2.setBackground(Color.white);
    report.add(r2);
    
     r1.addActionListener(this);
    r2.addActionListener(this);
    
     JMenu fee =new JMenu("Payment Detail");
    JMenuItem s1=new JMenuItem("Fee Structure");
    JMenuItem s2=new JMenuItem("Student Fee Form");
    JMenuItem s3=new JMenuItem("Teacher Salary");
    fee.setForeground(Color.BLUE);
    
    s1.setFont(new Font("monospace",Font.BOLD,16));
    s1.setMnemonic('L');
    s1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L,ActionEvent.CTRL_MASK));
    s1.setBackground(Color.white);
    fee.add(s1);
    
     s2.setFont(new Font("monospace",Font.BOLD,16));
    s2.setMnemonic('M');
    s2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M,ActionEvent.CTRL_MASK));
    s2.setBackground(Color.white);
    fee.add(s2);
    
     s3.setFont(new Font("monospace",Font.BOLD,16));
//  s3.setMnemonic('Z');
//    s3.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z,ActionEvent.CTRL_MASK));
    s3.setBackground(Color.white);
    fee.add(s3);
    
     s1.addActionListener(this);
    s2.addActionListener(this);
    s3.addActionListener(this);
    
     JMenu utility=new JMenu("Utility");
    JMenuItem k1=new JMenuItem("Notepad");
    JMenuItem k2=new JMenuItem("Calculater");
    JMenuItem k3=new JMenuItem("Library");
    utility.setForeground(Color.RED);
    
    k1.setFont(new Font("monospace",Font.BOLD,16));
    k1.setMnemonic('N');
    k1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,ActionEvent.CTRL_MASK));
    k1.setBackground(Color.white);
    utility.add(k1);
    
     k2.setFont(new Font("monospace",Font.BOLD,16));
    k2.setMnemonic('O');
    k2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,ActionEvent.CTRL_MASK));
    k2.setBackground(Color.white);
    utility.add(k2);
    
    k3.setFont(new Font("monospace",Font.BOLD,16));
    k3.setMnemonic('S');
    k3.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,ActionEvent.CTRL_MASK));
    k3.setBackground(Color.white);
    utility.add(k3);
    
     k1.addActionListener(this);
    k2.addActionListener(this);
    k3.addActionListener(this);
    
    JMenu about=new JMenu("About_Us");
    JMenuItem aa1=new JMenuItem("About Us");
    about.setForeground(Color.BLUE);
    
    aa1.setFont(new Font("monospace",Font.BOLD,16));
    aa1.setMnemonic('P');
    aa1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P,ActionEvent.CTRL_MASK));
    aa1.setBackground(Color.white);
    aa1.addActionListener(this);
    about.add(aa1);
    
      JMenu exit=new JMenu("Exit");
    JMenuItem e1=new JMenuItem("Exit");
    exit.setForeground(Color.RED);
    
   
    
    e1.setFont(new Font("monospace",Font.BOLD,16));
    e1.setMnemonic('Q');
    e1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,ActionEvent.CTRL_MASK));
    e1.setBackground(Color.white);
   e1.addActionListener(this);
    exit.add(e1);
    
    
    mb.add(master);
    mb.add(user);
    mb.add(attendance);
    mb.add(attendance_detail);
    mb.add(exam);
    mb.add(report);
    mb.add(fee);
    mb.add(utility);
    mb.add(about);
    mb.add(exit);
    con.add(mb);
    setJMenuBar(mb);
    
    setFont(new Font("Senserif",Font.BOLD,17));
    setLayout(new FlowLayout());
    setVisible(false);
}
    public void actionPerformed(ActionEvent ae){
        String msg=ae.getActionCommand();
        if(msg.equals("New Student")){
            
          new AddStudent().setVisible(true);
       
        }
         if(msg.equals("New Faculty")){
           new AddTeacher().setVisible(true);
            
        }
          if(msg.equals("Teacher Login")){
            
          new T_Login().setVisible(true);
       
          
            
        }
         if(msg.equals("Student Login")){
           new S_Login().setVisible(true);
            
        }
        if(msg.equals("Student Detail")){
           new StudentDetail().setVisible(true);
            
        }
        if(msg.equals("Teacher Detail")){
            new TeacherDetail().setVisible(true);
          
            
            
        }
        if(msg.equals("Update Student Detail")){
            new UpdateStudent().setVisible(true);
            
        }
        if(msg.equals("Update Teacher Detail")){
           new UpdateTeacher().setVisible(true);
            
        }
        if(msg.equals("Fee Structure")){
            new FeeStructure().setVisible(true);
            
        }
        if(msg.equals("Student Fee Form")){
          new FeeForm().setVisible(true);
            
        }
        
            if(msg.equals("Teacher Salary")){
          
          new Teacher_Salary().setVisible(true);
            
        }
        if(msg.equals("Notepad")){
          try{
              Runtime.getRuntime().exec("notepad.exe");}
          catch(Exception e){}
        }
          if(msg.equals("Calculater")){
          try{
              Runtime.getRuntime().exec("calc.exe");}
          catch(Exception e){}
        }
        if(msg.equals("Exit")){
        System.exit(0);
            
        } 
        if(msg.equals("About Us")){
           new About_Us().setVisible(true);
            
        }
        if(msg.equals("Student Attendance")){
           new StudentAttendance().setVisible(true);
            
        }
        if(msg.equals("Teacher Attendance")){
            new TeacherAttendance().setVisible(true);
            
        }
        if(msg.equals("Student Attendance Detail")){
            new Stud_Atte_Detail().setVisible(true);
            
        }
        if(msg.equals("Teacher Attendance Detail")){
            new teac_Atte_Detail().setVisible(true);
            
        }
        if(msg.equals("Examination Detail")){
            new Examination().setVisible(true);
            
        }
        if(msg.equals("Enter Mark")){
            new EnterMarks().setVisible(true);
            
        }
        if(msg.equals("Library")){
            new Library().setVisible(true);
            
        }
        
 }
    
    public static void main(String[] args) {
      Project p1=  new Project();
    p1.setVisible(true);
    }

    
    
}