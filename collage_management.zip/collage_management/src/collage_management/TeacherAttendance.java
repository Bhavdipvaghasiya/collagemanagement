package collage_management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class TeacherAttendance extends JFrame implements ActionListener {
    JLabel l1,l2,l3,l4,l5,l6,l7;
    JTextField t1,t2,t3,t4,t5,t6,t7;
    JButton b1,b2;
    Choice c2,fh,sh;
    
     public TeacherAttendance(){
         setVisible(true);
        setSize(400,450);
        Dimension dn =Toolkit.getDefaultToolkit().getScreenSize();
                int xx1=dn.width/2-this.getWidth()/2;
                int yy1=dn.height/2-this.getHeight()/2;
                setLocation(xx1,yy1);
    setLayout(null);
    c2=new Choice();
    
    try{
        conn c=new conn();
        ResultSet rs=c.s.executeQuery("select * from add_teacher");
        while(rs.next()){
        c2.add(rs.getString("emp_id"));
          c2.setBounds(200,50,100,30);
        
        }
    }catch(Exception e){}
    
    l4=new JLabel("Select rollno");
    l4.setBounds(70,50,100,30);
    l4.setFont(new Font("serif",Font.BOLD,15));
    add(l4);
    add(c2);
    
    l1=new JLabel("First Half");
     l1.setBounds(70,100,100,30);
    l1.setFont(new Font("serif",Font.BOLD,15));
    fh=new Choice();
    fh.add("Present");
    fh.add("Absent");
    fh.add("Leave");
    fh.setBounds(200,100,100,50);
    add(l1);
    add(fh);
    
    l2=new JLabel("Second Half");
   l2.setBounds(70,160,100,30);
    l2.setFont(new Font("serif",Font.BOLD,15));;
    sh=new Choice();
    sh.add("Present");
    sh.add("Absent");
    sh.add("Leave");
    sh.setBounds(200,160,100,30);
    add(l2);
    add(sh);
    
    b1=new JButton("submit");
    b1.setBackground(Color.black);
    b1.setForeground(Color.white);
       b1.setBounds(80,250,100,30);
    
     b2=new JButton("Cancel");
    b2.setBackground(Color.black);
    b2.setBounds(200,250,100,30);
    b2.setForeground(Color.white);
    
    b1.addActionListener(this);
    b2.addActionListener(this);
    add(b1);
    add(b2);
    
    getContentPane().setBackground(Color.white);
    
   }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==b1){
    String f=fh.getSelectedItem();
    String s=sh.getSelectedItem();
    String dt=new java.util.Date().toString();
    String id=c2.getSelectedItem();
     
    String qry="insert into attendance_teacher values('"+id+"','"+dt+"','"+f+"','"+s+"')";
    try{
        
    conn c1=new conn();
    
  int a= c1.s.executeUpdate(qry);
    JOptionPane.showMessageDialog(null,"Attendance confimed");
    this.setVisible(false);
   
    }
    catch(Exception ee){System.out.println(ee);}
    }
    if(ae.getSource()==b2){
    this.setVisible(false);
  // new Project().setVisible(true);
    }}

    public static void main(String[] args) {
         TeacherAttendance sa=new TeacherAttendance();
//       sa.setVisible(true);
//        sa.setSize(400,450);
      
    }
    
}
