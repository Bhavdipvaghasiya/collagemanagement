package collage_management;

import java.awt.*;
import javax.swing.*;
import java.awt.Dimension;

public class About_Us extends JFrame{

    private JPanel contentPane;
    
    public About_Us(){
       
        super("About Us-S.S.D.I.I.T-Collage");
                setBackground(new Color(172,216,230));
                setBounds(500,250,700,500);
                Dimension dn =Toolkit.getDefaultToolkit().getScreenSize();
                int xx1=dn.width/2-this.getWidth()/2;
                int yy1=dn.height/2-this.getHeight()/2;
                setLocation(xx1,yy1);
                
                
                contentPane=new JPanel();
                setContentPane(contentPane);
                contentPane.setLayout(null);
                
                JLabel l1=new JLabel("new Label");
                 ImageIcon i1=new ImageIcon(getClass().getResource("/collage_management/icon/im2.jpg"));
                  Image i2=i1.getImage().getScaledInstance(250,100,Image.SCALE_DEFAULT);
                    ImageIcon i3=new ImageIcon(i2);
                 l1=new JLabel(i3);
                l1.setBounds(400,40,250,100);
                contentPane.add(l1);
                
                JLabel l3=new JLabel("Collage");
                l3.setForeground(new Color(0,250,154));
                l3.setFont(new Font("Trebuchet MS",Font.BOLD,34));
                l3.setBounds(140,40,200,55);
                contentPane.add(l3);
                
                 JLabel l4=new JLabel("Manegement System");
                l4.setForeground(new Color(127,255,0));
                l4.setFont(new Font("Trebuchet MS",Font.BOLD,34));
                l4.setBounds(70,90,405,40);
                contentPane.add(l4);
                
                 JLabel l5=new JLabel("V1.1");
                l5.setForeground(new Color(30,144,255));
                l5.setFont(new Font("Trebuchet MS",Font.BOLD,25));
                l5.setBounds(185,140,100,21);
                contentPane.add(l5);
                
                 JLabel l6=new JLabel("Devloped By :Bhavdip Vaghasiya | Kishan Paghadal");
                l6.setForeground(new Color(4,25,54));
                l6.setFont(new Font("Trebuchet MS",Font.BOLD,20));
                l6.setBounds(70,198,600,35);
                contentPane.add(l6);
                
                 JLabel l7=new JLabel("Contact:vaghasiyabhavdip1111@gmail.com");
                l7.setForeground(new Color(80,20,14));
                l7.setFont(new Font("Trebuchet MS",Font.BOLD,20));
                l7.setBounds(70,260,600,34);
                contentPane.add(l7);
                
                 JLabel l8=new JLabel("Education - Bca(Computer Science");
                l8.setForeground(new Color(10,50,14));
                l8.setFont(new Font("Trebuchet MS",Font.BOLD,20));
                l8.setBounds(70,320,600,34);
                contentPane.add(l8);
                
                 JLabel l9=new JLabel("Phone - 6454218099  | 9898655140");
               l9.setForeground(new Color(45,50,154));
                l9.setFont(new Font("Trebuchet MS",Font.BOLD,20));
                l9.setBounds(70,380,600,34);
                contentPane.add(l9);
                
                contentPane.setBackground(Color.white);
    }
    
    public static void main(String[] args) {
    new About_Us().setVisible(true);    
    }
    
}
