package collage_management;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class teac_Atte_Detail extends JFrame implements ActionListener {
    JTable j1;
    JButton b1;
    String h[]={"Employee Id","Date Time","First Half","Second Half"};
    String d[][]=new String [15][4];
    int i=0,j=0;
    
    teac_Atte_Detail(){
    
    super("Student Attendance Detail");
     setVisible(true);
      setSize(800,300);
        Dimension dn =Toolkit.getDefaultToolkit().getScreenSize();
                int xx1=dn.width/2-this.getWidth()/2;
                int yy1=dn.height/2-this.getHeight()/2;
                setLocation(xx1,yy1);
    try{
        String q="select * from attendance_teacher";
        conn c1=new conn();
        ResultSet rs=c1.s.executeQuery(q);
        while(rs.next()){
        d[i][j++]=rs.getString("Emp_id");
        d[i][j++]=rs.getString("Date");
        d[i][j++]=rs.getString("First");
        d[i][j++]=rs.getString("Second");
        i++;
        j=0;
        }
        j1=new JTable(d,h);
        j1.setEnabled(false);
    }
    catch(Exception e){}
    setLayout(new BorderLayout());
    b1=new JButton("Print");
    add(b1,"South");
    JScrollPane s1=new JScrollPane(j1);
    add(s1);
    
    b1.addActionListener(this);
    
    }
    public void actionPerformed(ActionEvent ae){
    try{
    j1.print();
    
    }
    catch(Exception e){}
    }

    public static void main(String[] args) {
        teac_Atte_Detail tad=new teac_Atte_Detail();
       tad.setVisible(true);
        tad.setSize(800,300);
        //tad.setLocation(450,150);*/
    }
    }
    

