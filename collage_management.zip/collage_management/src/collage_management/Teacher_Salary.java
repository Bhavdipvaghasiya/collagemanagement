
package collage_management;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Teacher_Salary extends JFrame implements ActionListener {

   




    private  JPanel contentPane;
    private JTextField t1,t2,t3;
    private JComboBox comboBox,combobox_1,comboBox_2,comboBox_3;
    JButton b1,b2;
    JLabel v1;
    Choice c1;  
   
    public Teacher_Salary(){
    super("Teacher Salary Payment");
    setBounds(700,200,550,450);

  
   setSize(400,450);
    Dimension din=Toolkit.getDefaultToolkit().getScreenSize();
            int x=din.width/2-this.getWidth()/2;
            int y=din.height/2-this.getHeight()/2;
            setLocation(x,y);
            setResizable(false);
    contentPane=new JPanel();
    contentPane.setBorder(new EmptyBorder(5,5,5,5));
    setContentPane(contentPane);
    contentPane.setLayout(null);
    
    c1=new Choice();
    c1.setForeground(new Color(23,45,75));
    c1.setFont(new Font("Trebuchet MS",Font.BOLD,14));
    
    try{
    conn c=new conn();
    ResultSet rs=c.s.executeQuery("select * from add_teacher");
    while(rs.next()){
    c1.add(rs.getString("Emp_Id"));
    }
    }
   
    catch(Exception e){}
    
    JLabel l1=new JLabel("Select Emp_Id");
    l1.setForeground(new Color(23,45,17));
    l1.setFont(new Font("Tahoma",Font.BOLD,14));
    l1.setBounds(64,63,102,32);
    contentPane.add(l1);
    
     JLabel l2=new JLabel("Name");
    l2.setForeground(new Color(25,25,112));
    l2.setFont(new Font("Tahoma",Font.BOLD,14));
    l2.setBounds(64,97,102,22);
    contentPane.add(l2);
    
     JLabel l3=new JLabel("Father_Name");
    l3.setForeground(new Color(23,55,17));
    l3.setFont(new Font("Tahoma",Font.BOLD,14));
    l3.setBounds(64,130,102,22);
    contentPane.add(l3);
    
     JLabel l4=new JLabel("Brance");
    l4.setForeground(new Color(43,55,17));
    l4.setFont(new Font("Tahoma",Font.BOLD,14));
    l4.setBounds(64,209,102,22);
    contentPane.add(l4);
    
  
    
     JLabel l6=new JLabel("Total_Payable");
    l6.setForeground(new Color(23,55,17));
    l6.setFont(new Font("Tahoma",Font.BOLD,14));
    l6.setBounds(64,275,102,22);
    contentPane.add(l6);
    
    c1.setBounds(174,66,156,20);
    contentPane.add(c1);
    
    t2=new JTextField();
    t2.setForeground(new Color(34,65,86));
    t2.setEditable(false);
    t2.setFont(new Font("Trebuchat MS",Font.BOLD,14));
    t2.setColumns(10);
    t2.setBounds(174,100,156,20);
    contentPane.add(t2);
    
     t3=new JTextField();
    t3.setForeground(new Color(34,65,86));
    t3.setEditable(false);
    t3.setFont(new Font("Trebuchat MS",Font.BOLD,14));
    t3.setColumns(10);
    t3.setBounds(174,133,156,20);
    contentPane.add(t3);
    
    try{
    conn c=new conn();
    ResultSet rs=c.s.executeQuery("select * from Add_teacher where emp_id='"+c1.getSelectedItem()+"'");
    while(rs.next()){
    t2.setText(rs.getString("name"));
    t3.setText(rs.getString("fathers_name"));
    
    }
    }
    catch(Exception e){}
  comboBox=new JComboBox();
    comboBox.setModel(new DefaultComboBoxModel(new String[]{"Science","Computer","Commerce"}));
    comboBox.setForeground(new Color(34,56,28));
    comboBox.setFont(new Font("Trebuchet MS",Font.BOLD,14));
    comboBox.setBounds(176,211,154,20);
    contentPane.add(comboBox);
    
    
  
    v1=new JLabel();
      v1.setForeground(Color.red);
    v1.setFont(new Font("Tahoma",Font.BOLD,12));
    v1.setBounds(176,300,154,12);
    contentPane.add(v1);
    
     t1=new JTextField();
    t1.setForeground(new Color(34,65,86));
    t1.setFont(new Font("Trebuchat MS",Font.BOLD,14));
    t1.setColumns(10);
    t1.setBounds(176,275,154,20);
     String st1="^[0-9]{3,6}$";
    t1.addKeyListener(new KeyAdapter(){
        public void keyReleased(KeyEvent ke){
            Pattern pt=Pattern.compile(st1);
            Matcher mt=pt.matcher(t1.getText());
            if(mt.matches()){
             v1.setText("true");
            v1.setForeground(Color.green);
            }
            else{
            v1.setText("Input Strong Password");
            v1.setForeground(Color.red);
            }
        }
    });
    contentPane.add(t1);
    
    b1=new JButton ("Pay");
    b1.addActionListener(this);
    b1.setForeground(Color.black);
    b1.setFont(new Font("Trebuchet MS",Font.BOLD,14));
    b1.setBounds(64,321,111,33);
    b1.setBackground(Color.white);
     contentPane.add(b1);
   
   b2=new JButton ("Back");
  
    b2.setFont(new Font("Trebuchet MS",Font.BOLD,14));
    b2.setBounds(198,321,111,33);
    b2.setBackground(Color.white);
      b2.setForeground(Color.black);
    b2.addActionListener(this);
    contentPane.add(b2);
    
     JLabel l7=new JLabel("Course");
    l7.setForeground(new Color(23,55,17));
    l7.setFont(new Font("Tahoma",Font.BOLD,14));
    l7.setBounds(64,173,102,22);
    contentPane.add(l7);
    
     comboBox_3=new JComboBox();
    comboBox_3.setModel(new DefaultComboBoxModel(new String[]{"Bca","Bba,","Bsc","Mba","Btech"}));
    comboBox_3.setForeground(new Color(34,56,28));
    comboBox_3.setFont(new Font("Trebuchet MS",Font.BOLD,14));
    comboBox_3.setBounds(176,176,154,20);
    contentPane.add(comboBox_3);
    
    JPanel panel=new JPanel();
    panel.setBorder(new TitledBorder(new LineBorder(new Color(102,205,170),2,true),"Fee-Form",TitledBorder.LEADING,TitledBorder.TOP,null,new Color(30,144,255)));
    panel.setBackground(new Color(34,56,255));
    panel.setBounds(10,30,358,349);
    
    contentPane.setBackground(Color.white);
    panel.setBackground(Color.white);
    contentPane.add(panel);
    
     
    }
    public void actionPerformed(ActionEvent ae){String st1=t1.getText();
    if(ae.getSource()==b1){
        if(st1.isEmpty()){
        JOptionPane.showMessageDialog(null,"Empty Filled Not Allow");
        }
        else{
            try{
            conn con=new conn();
            if(v1.getText().equals("true")){
            String  s1="insert into salary values(?,?,?,?,?,?)";
            PreparedStatement st=con.c.prepareStatement(s1);
            st.setString(1,c1.getSelectedItem());
            st.setString(2,t2.getText());
            st.setString(3,t3.getText());
            st.setString(4,(String) comboBox_3.getSelectedItem());
            st.setString(5,(String) comboBox.getSelectedItem());
           
              st.setString(6,t1.getText());
            
            int i=st.executeUpdate();
            if(i>0){
            JOptionPane.showMessageDialog(null,"Successfully paid");
            this.setVisible(false);
            }
            else{
            JOptionPane.showMessageDialog(null,"Error");
            
            }
          
            
            
        }
              else{
                JOptionPane.showMessageDialog(null,"Plase Valid Data Enter");
                }
          }
            catch(Exception e){
                System.out.println(e);
            }
        
        }
    }
    if(ae.getSource()==b2){
            this.setVisible(false);
    
    }

    }
     public static void main(String[] args) {
     new Teacher_Salary().setVisible(true);
       
       
        
    }
    }


    
    

