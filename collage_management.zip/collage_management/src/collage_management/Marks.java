
package collage_management;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Marks extends JFrame  
{  
    JTextArea t1;
    JPanel p1;
    
   public Marks(){}
    public Marks(String str)
    {
     setSize(500,600);
     setLayout(new BorderLayout());
     Dimension dn =Toolkit.getDefaultToolkit().getScreenSize();
                int xx1=dn.width/2-this.getWidth()/2;
                int yy1=dn.height/2-this.getHeight()/2;
                setLocation(xx1,yy1);
    
     p1= new JPanel();
     t1= new JTextArea(50,15);
     JScrollPane jsp = new JScrollPane(t1);
     t1.setFont(new Font("senserif",Font.ITALIC,16));
     add(p1,"North");
     add(jsp,"Center");
    
     Mark(str);
     
     
     
    }
    public void Mark(String s)
    {
      try
      {
          
          conn c= new conn();
          t1.setText("\tResult of Examinetion\n\n subject\n");
         
          ResultSet rs1= c.s.executeQuery("select * from subject where rollno="+s);
          

          if(rs1.next())
          {
                       // JOptionPane.showMessageDialog(null,"Invalide Password");
           t1.append("\n\t"+rs1.getString("subject1"));
           t1.append("\n\t"+rs1.getString("subject2"));
           t1.append("\n\t"+rs1.getString("subject3"));
           t1.append("\n\t"+rs1.getString("subject4"));
           t1.append("\n\t"+rs1.getString("subject5"));
           t1.append("\n_______________________________________________________");
           t1.append("\t");
           t1.append("\n");
           
           
          

                    
      ResultSet rs2= c.s.executeQuery("select * from marks where rollno="+s);
                
      if(rs2.next())
      {         
        int mark1=Integer.parseInt(rs2.getString("marks1"));
        int mark2=Integer.parseInt(rs2.getString("marks2"));
        int mark3=Integer.parseInt(rs2.getString("marks3"));
        int mark4=Integer.parseInt(rs2.getString("marks4"));
        int mark5=Integer.parseInt(rs2.getString("marks5"));
        int total=mark1+mark2+mark3+mark4+mark5;
        
        
        t1.append("\nmarks\n\n\t"+rs2.getString("marks1"));
           t1.append("\n\t"+rs2.getString("marks2"));
           t1.append("\n\t"+rs2.getString("marks3"));
           t1.append("\n\t"+rs2.getString("marks4"));
           t1.append("\n\t"+rs2.getString("marks5"));
           t1.append("\n_______________________________________________________");
           t1.append("\t");
           t1.append("\ntotalMarks:   ");
           t1.append(total+"/500");
      }
      }

          else{
                    JOptionPane.showMessageDialog(null,"Not Result Found");
                
                  new Examination().setVisible(true);
                  // this.setVisible(false);
                 
                    
          }
      }
      catch(Exception e)
      {
      e.printStackTrace();
      }
    }
    
    public static void main(String[] args) {
     new Marks().setVisible(true);
    }
    
}
